"""ChatGPT 데이터 분석 환경에서 실행합니다. 입력 JSON과 함께 첨부합니다."""
import json, sys
from pathlib import Path
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint

def candidates(d, mode='profit'):
    out=[]
    for p in d['products']:
        for v in d['vendors']:
            quote=next(q for q in d['quotes'] if q['sku']==p['sku'] and q['vendor']==v['id'])
            for week in [1,2]:
                arrive=week+v['lead']-1
                for qty in range(quote['minimum'],quote['capacity']+1,p['pack']):
                    unit=quote['unit']*(1-quote['discount'] if qty>=quote['threshold'] else 1)
                    unit=round(unit)
                    for demand in p['demand']:
                        if mode=='cost' and demand['case']!='기준': continue
                        sales=demand['qty']; end=p['stock']+p['pending']+qty-sales
                        if end<p['safety'] or end>p['max_end']: continue
                        # 확정주문 W2, 추가 판매 W4. 기존 입고는 W1입니다.
                        if p['stock']+p['pending']+(qty if arrive<=2 else 0)<p['firm']: continue
                        if arrive>4: continue
                        old_use=min(sales,p['stock']+p['pending'])
                        cogs=old_use*p['old_cost']+(sales-old_use)*unit
                        revenue=p['firm']*p['firm_price']+(sales-p['firm'])*demand['price']
                        holding=end*p['holding']
                        cost=qty*unit+v['freight']
                        payweek=min(5,arrive+v['pay_delay'])
                        paid=[cost if payweek==w else 0 for w in range(1,5)]
                        receipts=[0,0,p['firm']*p['firm_price']*.5,revenue*.5-p['firm']*p['firm_price']*.5]
                        # 확정 매출의 50%는 W3, 추가 매출의 50%는 W4, 전체 매출의 나머지 50%는 다음 달 수금.
                        stocks=[p['stock']+p['pending']+(qty if arrive<=w else 0)-(p['firm'] if w>=2 else 0)-(sales-p['firm'] if w>=4 else 0) for w in range(1,5)]
                        peaks=[stocks[w-1]+(p['firm'] if w==2 else sales-p['firm'] if w==4 else 0) for w in range(1,5)]
                        out.append(dict(sku=p['sku'],name=p['name'],vendor=v['id'],week=week,arrive=arrive,payweek=payweek,qty=qty,unit=unit,case=demand['case'],price=demand['price'],sales=sales,end=end,revenue=revenue,cogs=cogs,holding=holding,freight=v['freight'],cost=cost,profit=revenue-cogs-holding-v['freight'],paid=paid,receipts=receipts,stocks=stocks,peaks=peaks))
    return out

def solve(d,mode='profit'):
    opts=candidates(d,mode); n=len(opts)
    A=[]; lo=[]; hi=[]
    def row(vals,l=-np.inf,u=np.inf): A.append(vals);lo.append(l);hi.append(u)
    for p in d['products']: row([int(o['sku']==p['sku']) for o in opts],1,1)
    row([o['cost']/10000 for o in opts],u=d['budget']/10000)
    for v in d['vendors']:row([o['qty'] if o['vendor']==v['id'] else 0 for o in opts],u=v['total_capacity'])
    for w in range(4):
        row([o['peaks'][w] for o in opts],u=d['warehouse'])
        available=d['cash']+sum(d['recovery'][:w+1])-sum(d['opex_cash'][:w+1])-sum(d['old_ap'][:w+1])-d['min_cash']
        row([(sum(o['paid'][:w+1])-sum(o['receipts'][:w+1]))/10000 for o in opts],u=available/10000)
    c=np.array([-o['profit']/10000 if mode=='profit' else o['cost']/10000 for o in opts])
    res=milp(c,integrality=np.ones(n),bounds=Bounds(0,1),constraints=LinearConstraint(np.array(A),lo,hi),options={'time_limit':45,'mip_rel_gap':0.000001})
    if res.x is None:return {'status':int(res.status),'message':res.message,'candidates':n}
    picks=[o for o,x in zip(opts,res.x) if x>.5]
    values=np.array(A)@np.rint(res.x)
    feasible=bool(np.all(values>=np.array(lo)-1e-6) and np.all(values<=np.array(hi)+1e-6))
    cash=[];bal=d['cash']
    for w in range(4):
        inc=d['recovery'][w]+sum(o['receipts'][w] for o in picks)
        pay=d['opex_cash'][w]+d['old_ap'][w]+sum(o['paid'][w] for o in picks)
        bal+=inc-pay;cash.append(dict(week=w+1,inflow=inc,outflow=pay,balance=bal))
    totals={k:round(sum(o[k] for o in picks)) for k in ['qty','sales','end','revenue','cogs','holding','freight','cost','profit']}
    totals['operating_profit']=totals['profit']-d['opex']
    return dict(status=int(res.status),message=res.message,gap=float(res.mip_gap),candidates=n,feasible=feasible,mode=mode,totals=totals,cash=cash,picks=picks,scope='12상품 각각 한 업체·한 발주시점·한 가격수요 구간을 선택하는 제공 후보 범위')

if __name__=='__main__':
    src=Path(sys.argv[1]) if len(sys.argv)>1 else next(Path('.').rglob('05_최적화입력.json'))
    d=json.loads(src.read_text(encoding='utf-8-sig'))
    mode=sys.argv[2] if len(sys.argv)>2 else 'profit'
    result=solve(d,mode)
    dest=src.parent/('구매결과_'+mode+'.json');dest.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
